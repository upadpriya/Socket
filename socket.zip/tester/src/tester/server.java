package tester;

import java.io.*;
import java.net.*;

public class server {
	public static void main(String []args) throws IOException
	{
		ServerSocket ssoc = new ServerSocket(9655);
		Socket client=ssoc.accept();
		BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()));;
		
		while(true){
		String st = br.readLine();
		if(st.equals("exit")){
			System.out.println("Connection lost");
			ssoc.close();
			System.exit(1);
			
		}
		PrintStream ps = new PrintStream(client.getOutputStream());
		ps.println(st);
		
		}
	}
}
