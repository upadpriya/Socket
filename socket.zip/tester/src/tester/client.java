package tester;

import java.net.*;
import java.io.*;


public class client {
	public static void main(String []args) throws IOException
	{
		Socket csoc = new Socket("127.0.0.1", 9655);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedReader br1 = new BufferedReader(new InputStreamReader(csoc.getInputStream()));
		PrintStream ps = new PrintStream(csoc.getOutputStream());
		while(true){
		System.out.println("Enter string to echo: ");
		String s = br.readLine();
		ps.println(s);
		if(s.equals("exit")){
			csoc.close();
			System.exit(1);
			
		}
		
		String echo = br1.readLine();
		System.out.println("Echo: ");
		System.out.println(echo);
		}
		
	}
}
